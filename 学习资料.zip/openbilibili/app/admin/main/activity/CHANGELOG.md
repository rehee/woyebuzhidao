# activity-admin

## v1.1.5
1. kfc查询券码接口

## v1.1.4
1. account接入grpc

## v1.1.3
1. admin ipv4Toipv6

## v1.1.2
1. 批量上传稿件接口

## v1.1.1
1. php活动接口转go

## v1.1.0

1. 批量获取稿件信息

## v1.0.1

1. init bws

## v1.0.0

1. 初始化代码
